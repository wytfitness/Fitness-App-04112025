// app/workout/index.js
import { Redirect } from "expo-router";
export default function () { return <Redirect href="/workout/exercise-picker" />; }
