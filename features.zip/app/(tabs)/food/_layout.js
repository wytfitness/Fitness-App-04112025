import { Stack } from "expo-router";

export default function DiaryStack() {
  return <Stack screenOptions={{ headerShown: false }} />;
}